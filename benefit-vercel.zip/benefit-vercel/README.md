# Benefix on Vercel + Supabase

Free-to-join micro-task rewards app. The website and the API run on Vercel; all data lives in a Supabase Postgres database.

## 1. Create the database (Supabase)
1. Sign up at supabase.com and create a new project. Choose region **Central EU (Frankfurt)** and save the database password you set.
2. Open the project, press **Connect**, and copy the **Transaction pooler** connection string (port 6543). Put your real database password where it says `[YOUR-PASSWORD]`. You do not need to create any tables: the app creates them itself on its first request.

## 2. Put the code on GitHub
Create a private repository and upload everything in this folder (keep the `api` and `public` folders as they are).

## 3. Deploy on Vercel
1. Sign up at vercel.com with your GitHub account, press **Add New > Project**, and import the repository. Leave the framework as "Other" and do not change the build settings.
2. Before pressing Deploy, add these Environment Variables (see `.env.example`):
   - `DATABASE_URL` = the Supabase connection string from step 1
   - `SESSION_SECRET` = a long random text (32+ characters)
   - `ADMIN_EMAIL` = your email
   - `ADMIN_PASSWORD` = a strong password (8+ characters)
3. Press **Deploy**. When it finishes, open your `.vercel.app` link. The first page load creates the tables and your admin account. Log in with your admin email and password.
4. Your own domain: Project > Settings > Domains.

If Vercel complains about `regions` in `vercel.json`, delete that line. Keeping the Vercel region (Frankfurt) next to the Supabase region keeps the site fast.

## Test once before sharing
Register a test user, do both tasks, make a second account with the first one as inviter, request a withdrawal, then approve it in admin.

## Password reset
There is no email service. Press **Reset** next to a user in admin to get a one-hour link and send it to them (for example on WhatsApp).

## Before real people use it
- Rewards and referral bonuses must be paid from real income (advertisers, survey clients), never from user deposits. Do not charge activation fees.
- Withdrawals are manual: approve only after you have sent the money.
- You hold names, phone numbers and bank details, so protect that data (Nigeria Data Protection Act). Use a strong admin password and turn on Supabase backups.
- Check current Vercel and Supabase plan limits on their sites.
